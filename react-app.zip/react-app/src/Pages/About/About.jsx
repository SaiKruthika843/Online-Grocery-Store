import React from 'react'

const About = () => {
    return (
        <div style={{ minHeight: "80vh" }}>About</div>
    )
}

export default About